package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = VpnGray, // Initial idle color
    secondary = VpnSurface,
    background = VpnBackground,
    surface = VpnSurface,
    onBackground = VpnOnBackground,
    onSurface = VpnOnSurface,
    surfaceVariant = VpnSurfaceAccent,
    onSurfaceVariant = VpnOnSurfaceVariant
  )

@Composable
fun WindVPNTheme(
  isConnected: Boolean = false,
  // We force dark theme for the Professional Dark Theme requirement
  content: @Composable () -> Unit,
) {
  val colorScheme = if (isConnected) {
    DarkColorScheme.copy(
        primary = VpnBlue,
        secondaryContainer = VpnSurfaceAccent
    )
  } else {
    DarkColorScheme.copy(
        primary = VpnGray,
        secondaryContainer = VpnSurfaceAccent
    )
  }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
