package com.example

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.VpnService
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class VpnStatus {
    DISCONNECTED, CONNECTING, CONNECTED
}

/**
 * Senior Architect Implementation of VPN View Model.
 * Interfaces with WindVpnService to provide real-time connection status.
 */
class VpnViewModel(application: Application) : AndroidViewModel(application) {

    val status: StateFlow<VpnStatus> = WindVpnService.vpnStatus
    val connectionDuration: StateFlow<Long> = WindVpnService.connectionDuration

    private val _selectedLocation = MutableStateFlow("United States (New York)")
    val selectedLocation: StateFlow<String> = _selectedLocation.asStateFlow()

    val availableServers = listOf(
        "United States (New York)",
        "Germany (Frankfurt)",
        "Singapore",
        "Netherlands (Amsterdam)",
        "United Kingdom (London)"
    )

    fun selectServer(server: String) {
        if (status.value == VpnStatus.DISCONNECTED) {
            _selectedLocation.value = server
        }
    }

    fun connect(onAdFinished: () -> Unit) {
        viewModelScope.launch {
            if (status.value == VpnStatus.DISCONNECTED) {
                onAdFinished()
            } else if (status.value == VpnStatus.CONNECTED) {
                disconnect()
            }
        }
    }

    fun startConnecting() {
        val context = getApplication<Application>()
        
        // Ensure we have VPN permission (this usually happens in activity, but we trigger the intent)
        val intent = Intent(context, WindVpnService::class.java).apply {
            action = "ACTION_CONNECT"
            putExtra("EXTRA_SERVER", _selectedLocation.value)
        }
        context.startService(intent)
    }

    fun disconnect() {
        val context = getApplication<Application>()
        val intent = Intent(context, WindVpnService::class.java).apply {
            action = "ACTION_DISCONNECT"
        }
        context.startService(intent)
    }
}
