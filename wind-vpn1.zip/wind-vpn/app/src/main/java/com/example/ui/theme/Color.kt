package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

val VpnBlue = Color(0xFF00D2FF)
val VpnGray = Color(0xFF404040)
val VpnBackground = Color(0xFF0A0A0A)
val VpnSurface = Color(0xFF1A1A1A)
val VpnOnBackground = Color(0xFFFFFFFF)
val VpnOnSurface = Color(0xFFFFFFFF)
val VpnOnSurfaceVariant = Color(0xFFB0B0B0)
val VpnSurfaceAccent = Color(0xFF252525)
val VpnBorder = Color(0xFF2E2E2E)
val VpnGlow = Color(0x3300D2FF)
