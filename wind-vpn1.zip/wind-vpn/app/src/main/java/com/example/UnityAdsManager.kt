package com.example

import android.app.Activity
import android.util.Log
import com.unity3d.ads.IUnityAdsInitializationListener
import com.unity3d.ads.IUnityAdsLoadListener
import com.unity3d.ads.IUnityAdsShowListener
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsLoadOptions
import com.unity3d.ads.UnityAdsShowOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Senior Architect Implementation of Unity Ads Manager.
 * Features: Robust initialization, exponential backoff retries, thread-safe state tracking,
 * and comprehensive exception handling with ad unit fallback logic.
 */
class UnityAdsManager(private val activity: Activity) {
    private val gameId = "6180342"
    private val adUnitId = "rewardedVideo"
    private val fallbackAdUnitId = "Rewarded_Android"
    private var currentAdUnitId = adUnitId
    private val testMode = true // Set to false for production

    private val _isAdLoaded = MutableStateFlow(false)
    val isAdLoaded: StateFlow<Boolean> = _isAdLoaded.asStateFlow()

    private val _isInitializing = MutableStateFlow(false)
    val isInitializing: StateFlow<Boolean> = _isInitializing.asStateFlow()

    private var retryAttempt = 0
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    fun initialize() {
        if (UnityAds.isInitialized) {
            Log.d("UnityAds", "Already initialized, loading ad...")
            loadAd()
            return
        }

        if (_isInitializing.value) return
        _isInitializing.value = true

        try {
            UnityAds.setDebugMode(testMode)
            Log.d("UnityAds", "Initializing Unity Ads with Game ID: $gameId (Test Mode: $testMode)")
            UnityAds.initialize(activity.applicationContext, gameId, testMode, object : IUnityAdsInitializationListener {
                override fun onInitializationComplete() {
                    scope.launch {
                        _isInitializing.value = false
                        Log.d("UnityAds", "Initialization Successful")
                        retryAttempt = 0
                        delay(3000) // Increased delay to allow SDK to settle
                        loadAd()
                    }
                }

                override fun onInitializationFailed(error: UnityAds.UnityAdsInitializationError?, message: String?) {
                    scope.launch {
                        _isInitializing.value = false
                        Log.e("UnityAds", "Initialization Failed ($error): $message")
                        scheduleRetry(isInitRetry = true)
                    }
                }
            })
        } catch (e: Exception) {
            _isInitializing.value = false
            Log.e("UnityAds", "Exception during initialization: ${e.message}", e)
        }
    }

    fun loadAd(useFallback: Boolean = false) {
        if (!UnityAds.isInitialized) {
            Log.w("UnityAds", "Cannot load ad: SDK not initialized")
            initialize()
            return
        }

        if (useFallback) {
            currentAdUnitId = fallbackAdUnitId
            Log.w("UnityAds", "Attempting fallback ad unit: $currentAdUnitId")
        } else {
            currentAdUnitId = adUnitId
        }

        _isAdLoaded.value = false
        Log.d("UnityAds", "Loading ad unit: $currentAdUnitId (Attempt: ${retryAttempt + 1})")

        try {
            val loadOptions = UnityAdsLoadOptions()
            UnityAds.load(currentAdUnitId, loadOptions, object : IUnityAdsLoadListener {
                override fun onUnityAdsAdLoaded(placementId: String?) {
                    scope.launch {
                        Log.d("UnityAds", "Ad Loaded Successfully: $placementId")
                        _isAdLoaded.value = true
                        retryAttempt = 0
                    }
                }

                override fun onUnityAdsFailedToLoad(placementId: String?, error: UnityAds.UnityAdsLoadError?, message: String?) {
                    scope.launch {
                        Log.e("UnityAds", "Ad Failed to Load ($error): $message")
                        
                        // Handle the specific Header Bidding vs Waterfall mismatch error
                        if (message?.contains("adMarkup is missing") == true) {
                            Log.e("UnityAds", "DIAGNOSTIC: Bidding/Waterfall Mismatch detected for $placementId")
                            if (!useFallback) {
                                Log.w("UnityAds", "Detected Bidding placement. Trying generic Waterfall fallback...")
                                loadAd(useFallback = true)
                                return@launch
                            } else {
                                Log.e("UnityAds", "----------------------------------------------------------------")
                                Log.e("UnityAds", "CRITICAL: Ad Unit '$placementId' requires Bidding markup.")
                                Log.e("UnityAds", "Please change it to 'Waterfall' in Unity Dashboard.")
                                Log.e("UnityAds", "----------------------------------------------------------------")
                            }
                        }
                        
                        _isAdLoaded.value = false
                        scheduleRetry(isInitRetry = false)
                    }
                }
            })
        } catch (e: Exception) {
            Log.e("UnityAds", "Exception during load: ${e.message}", e)
            _isAdLoaded.value = false
        }
    }

    private fun scheduleRetry(isInitRetry: Boolean) {
        retryAttempt++
        val delayMs = (Math.pow(2.0, retryAttempt.toDouble()) * 1000).toLong().coerceAtMost(30000)
        Log.d("UnityAds", "Scheduling ${if (isInitRetry) "init" else "load"} retry in ${delayMs}ms")

        scope.launch {
            delay(delayMs)
            if (isInitRetry) initialize() else loadAd(useFallback = currentAdUnitId == fallbackAdUnitId)
        }
    }

    fun showRewardedAd(onReward: () -> Unit, onError: (String) -> Unit) {
        if (!_isAdLoaded.value) {
            Log.w("UnityAds", "Show failed: Ad not ready")
            onError("Ad is still preparing. Please try again in a few seconds.")
            loadAd(useFallback = currentAdUnitId == fallbackAdUnitId)
            return
        }

        try {
            Log.d("UnityAds", "Showing rewarded ad: $currentAdUnitId")
            UnityAds.show(activity, currentAdUnitId, UnityAdsShowOptions(), object : IUnityAdsShowListener {
                override fun onUnityAdsShowFailure(placementId: String?, error: UnityAds.UnityAdsShowError?, message: String?) {
                    scope.launch {
                        Log.e("UnityAds", "Ad Show Failed ($error): $message")
                        _isAdLoaded.value = false
                        loadAd(useFallback = currentAdUnitId == fallbackAdUnitId)
                        onError("Failed to show ad: $message")
                    }
                }

                override fun onUnityAdsShowStart(placementId: String?) {
                    Log.d("UnityAds", "Ad started showing")
                }

                override fun onUnityAdsShowClick(placementId: String?) {
                    Log.d("UnityAds", "Ad clicked")
                }

                override fun onUnityAdsShowComplete(placementId: String?, state: UnityAds.UnityAdsShowCompletionState?) {
                    scope.launch {
                        Log.d("UnityAds", "Ad show complete with state: $state")
                        _isAdLoaded.value = false
                        if (state == UnityAds.UnityAdsShowCompletionState.COMPLETED) {
                            onReward()
                        } else {
                            onError("Ad not completed. Reward withheld.")
                        }
                        loadAd(useFallback = currentAdUnitId == fallbackAdUnitId)
                    }
                }
            })
        } catch (e: Exception) {
            Log.e("UnityAds", "Exception during show: ${e.message}", e)
            _isAdLoaded.value = false
            onError("An unexpected error occurred while showing the ad.")
        }
    }

    fun onDestroy() {
        Log.d("UnityAds", "Destroying Ads Manager")
        scope.cancel()
    }
}
