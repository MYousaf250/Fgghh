package com.example

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    private lateinit var adsManager: UnityAdsManager
    private lateinit var viewModel: VpnViewModel

    private val vpnPrepareLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            viewModel.startConnecting()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        adsManager = UnityAdsManager(this)
        adsManager.initialize()
        
        viewModel = VpnViewModel(application)

        setContent {
            val vpnStatus by viewModel.status.collectAsState()
            
            WindVPNTheme(isConnected = vpnStatus == VpnStatus.CONNECTED) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    VpnHomeScreen(
                        viewModel = viewModel,
                        adsManager = adsManager,
                        onPrepareVpn = { prepareVpn() }
                    )
                }
            }
        }
    }

    private fun prepareVpn() {
        val intent = VpnService.prepare(this)
        if (intent != null) {
            vpnPrepareLauncher.launch(intent)
        } else {
            viewModel.startConnecting()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        adsManager.onDestroy()
    }
}

@Composable
fun VpnHomeScreen(
    viewModel: VpnViewModel,
    adsManager: UnityAdsManager,
    onPrepareVpn: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isAdLoaded by adsManager.isAdLoaded.collectAsState()
    val vpnStatus by viewModel.status.collectAsState()
    val selectedLocation by viewModel.selectedLocation.collectAsState()
    val duration by viewModel.connectionDuration.collectAsState()
    val availableServers = viewModel.availableServers
    
    var showServerDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(VpnSurface, VpnBackground),
                    center = androidx.compose.ui.geometry.Offset.Unspecified,
                    radius = Float.POSITIVE_INFINITY
                )
            )
            .padding(horizontal = 24.dp, vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header (Minimal)
        Text(
            text = "WIND VPN",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onBackground,
            letterSpacing = 4.sp
        )

        Spacer(modifier = Modifier.height(48.dp))

        // Status Section
        VpnStatusSection(status = vpnStatus)

        Spacer(modifier = Modifier.weight(1f))

        // Connect Button Section
        VpnConnectSection(
            status = vpnStatus,
            isAdLoaded = isAdLoaded,
            onConnectClick = {
                viewModel.connect {
                    adsManager.showRewardedAd(
                        onReward = {
                            onPrepareVpn()
                        },
                        onError = { message ->
                            android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        )

        Spacer(modifier = Modifier.height(48.dp))

        // Server Selection Card
        ServerSelectionCard(
            location = selectedLocation,
            onClick = { if (vpnStatus == VpnStatus.DISCONNECTED) showServerDialog = true }
        )

        Spacer(modifier = Modifier.weight(1f))

        // Duration Info
        if (vpnStatus == VpnStatus.CONNECTED) {
            Text(
                text = formatDuration(duration),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Light,
                color = VpnBlue,
                letterSpacing = 2.sp
            )
        } else {
            // Ad Badge (Minimal)
            AdBadge(isAdLoaded = isAdLoaded)
        }
    }

    if (showServerDialog) {
        ServerSelectionDialog(
            servers = availableServers,
            currentSelection = selectedLocation,
            onSelect = { 
                viewModel.selectServer(it)
                showServerDialog = false
            },
            onDismiss = { showServerDialog = false }
        )
    }
}

@Composable
fun VpnStatusSection(status: VpnStatus) {
    val statusText = when (status) {
        VpnStatus.DISCONNECTED -> "PROTECTION OFF"
        VpnStatus.CONNECTING -> "ESTABLISHING..."
        VpnStatus.CONNECTED -> "PROTECTION ON"
    }
    
    val statusColor = if (status == VpnStatus.CONNECTED) VpnBlue else VpnOnSurfaceVariant

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = statusText,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = statusColor,
            letterSpacing = 2.sp
        )
    }
}

@Composable
fun VpnConnectSection(
    status: VpnStatus,
    isAdLoaded: Boolean,
    onConnectClick: () -> Unit
) {
    val isConnected = status == VpnStatus.CONNECTED
    val isConnecting = status == VpnStatus.CONNECTING
    
    Box(contentAlignment = Alignment.Center) {
        // Glowing Aura
        if (isConnected || isConnecting) {
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(VpnBlue.copy(alpha = 0.2f), Color.Transparent)
                        )
                    )
            )
        }

        // Main Power Button
        Surface(
            onClick = onConnectClick,
            enabled = !isConnecting,
            modifier = Modifier
                .size(180.dp)
                .shadow(
                    elevation = if (isConnected) 40.dp else 0.dp,
                    shape = CircleShape,
                    spotColor = VpnBlue,
                    ambientColor = VpnBlue
                )
                .border(
                    width = 2.dp,
                    brush = Brush.linearGradient(
                        colors = if (isConnected) listOf(VpnBlue, VpnBlue.copy(alpha = 0.5f))
                                 else listOf(VpnGray, VpnGray.copy(alpha = 0.5f))
                    ),
                    shape = CircleShape
                )
                .testTag("connect_button"),
            shape = CircleShape,
            color = VpnBackground
        ) {
            Box(contentAlignment = Alignment.Center) {
                if (!isConnected && !isConnecting && !isAdLoaded) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = VpnBlue,
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.PowerSettingsNew,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = if (isConnected) VpnBlue else VpnGray
                    )
                }
                
                if (isConnecting) {
                    CircularProgressIndicator(
                        modifier = Modifier.fillMaxSize().padding(4.dp),
                        color = VpnBlue,
                        strokeWidth = 2.dp
                    )
                }
            }
        }
    }
}

@Composable
fun ServerSelectionCard(
    location: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(80.dp),
        shape = RoundedCornerShape(24.dp),
        color = VpnSurface,
        border = BorderStroke(1.dp, VpnBorder)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 24.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Public,
                    contentDescription = null,
                    tint = VpnBlue,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "SERVER LOCATION",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = VpnOnSurfaceVariant,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = location,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold,
                        color = VpnOnSurface
                    )
                }
            }
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = VpnOnSurfaceVariant
            )
        }
    }
}

@Composable
fun AdBadge(isAdLoaded: Boolean) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
        modifier = Modifier.padding(vertical = 16.dp)
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (isAdLoaded) VpnBlue else VpnGray)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = if (isAdLoaded) "PREMIUM AD READY" else "FETCHING AD...",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = if (isAdLoaded) VpnBlue else VpnGray,
            letterSpacing = 1.sp
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServerSelectionDialog(
    servers: List<String>,
    currentSelection: String,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = VpnSurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
                .padding(bottom = 32.dp)
        ) {
            Text(
                text = "SELECT SERVER",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = VpnOnSurface,
                letterSpacing = 2.sp,
                modifier = Modifier.padding(bottom = 24.dp)
            )
            
            servers.forEach { server ->
                Surface(
                    onClick = { onSelect(server) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    color = if (server == currentSelection) VpnSurfaceAccent else Color.Transparent,
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Place,
                            contentDescription = null,
                            tint = if (server == currentSelection) VpnBlue else VpnGray,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = server,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = if (server == currentSelection) FontWeight.Bold else FontWeight.Medium,
                            color = if (server == currentSelection) VpnBlue else VpnOnSurface
                        )
                        if (server == currentSelection) {
                            Spacer(modifier = Modifier.weight(1f))
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = VpnBlue,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

fun formatDuration(seconds: Long): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return String.format("%02d:%02d:%02d", h, m, s)
}
